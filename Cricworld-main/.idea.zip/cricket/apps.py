from django.apps import AppConfig


class CircketConfig(AppConfig):
    name = 'circket'
