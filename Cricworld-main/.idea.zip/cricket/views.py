from django.shortcuts import render
import json
import requests
from collections import defaultdict


# Create your views here.
def index(request):
    return render(request, "index.html", dict(link1='home'))

def overs(resS) :
    S = resS['data']['bowling'][0]['scores']
    Oone = 0
    Otwo = 0
    for i in S :
        Oone  = Oone + float(i['O'])
    if len(resS['data']['bowling']) > 1 :
        T = resS['data']['bowling'][1]['scores']
        for i in T:
            Otwo = Otwo + float(i['O'])

    over = { "Oone" : Oone , "Otwo" : Otwo}
    return  over

def home(request, endfor=None):
    keys = ["2CKFCOve0rdpvaKLOZQBxZzfOqn1",
            "SXCi9B1KSHOo5A9209U6x9nXmHm2",
            "WmUasHazyvYrXqyz9pYpmgeqOI72",
            "srZuPbXxGNQ4i0VxAHOudEx3jLv1"
            ]
    ID = ""
    res = defaultdict()
    for i in keys :
        res = json.loads(requests.get(f'http://cricapi.com/api/cricket/?apikey={i}').text)
        if not 'error' in res.keys() :
            ID = i
            break


    # Cricapi Calls()
    resC = res
    resc = json.loads(requests.get(f'http://cricapi.com/api/matches/?apikey={ID}').text)
    resS = defaultdict()
    for i in range(len(resC['data'])) :
        for j in range(len(resc['matches'])) :
            if(int(resC['data'][i]['unique_id']) == resc['matches'][j]['unique_id']) :
                if 'toss_winner_team' in resc['matches'][j].keys()  :       #If toss has happened or not
                    resC['data'][i]['t_team_name'] = resc['matches'][j]['toss_winner_team']
                    resC['data'][i]['localteam'] = resc['matches'][j]['team-1']
                    resC['data'][i]['visitorteam'] = resc['matches'][j]['team-2']

                    I = resC['data'][i]['unique_id']
                    resS = json.loads(requests.get(f'http://cricapi.com/api/fantasySummary/?apikey={ID}&unique_id={I}').text)  #here f'' is included because we need to include variab;es there
                    resS,resC,i,j,resc
                    if(len(resS['data']['fielding']) > 0) :     #To check if match started or not
                        resC['data'][i]['match_started'] = 'true'
                        a = resS['data']['fielding'][0]['title']
                        b = resc['matches'][j]['toss_winner_team']

                        #Adding Toss winner name and their decision
                        if(a[13:18] == b[0:5]) :
                            resC['data'][i]['elected'] = "bat"
                            if(resc['matches'][j]['toss_winner_team'] == resc['matches'][j]['team-1']) :
                                resC['data'][i]['batfirst'] = resc['matches'][j]['team-1']
                                resC['data'][i]['batsecond'] = resc['matches'][j]['team-2']
                            else :
                                resC['data'][i]['batfirst'] = resc['matches'][j]['team-2']
                                resC['data'][i]['batsecond'] = resc['matches'][j]['team-1']
                        else :
                            resC['data'][i]['elected'] = "bowl"
                            if (resc['matches'][j]['toss_winner_team'] == resc['matches'][j]['team-1']):
                                resC['data'][i]['batfirst'] = resc['matches'][j]['team-2']
                                resC['data'][i]['batsecond'] = resc['matches'][j]['team-1']
                            else:
                                resC['data'][i]['batfirst'] = resc['matches'][j]['team-1']
                                resC['data'][i]['batsecond'] = resc['matches'][j]['team-2']

                        # Adding match date
                        resC['data'][i]['pubDate'] = resc['matches'][j]['date']

                        #Adding overs
                        over = overs(resS)
                        l = len(resC['data'][i]['description'])
                        for index in range(5,l) :
                            if (resC['data'][i]['description'][index] == '/'):
                                sone = resC['data'][i]['description'][0:index + 3]
                                stwo = '(' + str(over['Oone']) + ')'
                                resC['data'][i]['score1'] = sone + stwo
                                sthree = resC['data'][i]['description'][index + 5:]
                                if resC['data'][i]['description'][l-1] =='*' :
                                    sfour = '(' + str(over['Otwo']) + ')'
                                    resC['data'][i]['score2'] = sthree + sfour
                                else :
                                    resC['data'][i]['score2'] = sthree
                                break
                        if resS['data']['man-of-the-match']!="" :
                               resS['man_of_the_match'] = resS['data']['man-of-the-match']['name']

                        else :
                            resS['man_of_the_match'] = "null"

                        if not "winner_team" in resS :
                            resS["winner_team"] = "null"
                        else :
                            resS["winner_team"] = resS['data']['winner_team']
                        resC['data'][i]["winner_team"] = resS["winner_team"]
                        resC['data'][i]["man_of_the_match"] = resS["man_of_the_match"]
                        break
                    else :
                        resC['data'][i]['match_started'] = 'false'
                else :
                    resC['data'][i]['match_started'] = 'false'

    return render(request, "home.html", {'resC' : resC['data']})

def scoreboard(request,id):
    id = int(id)
    keys = ["2CKFCOve0rdpvaKLOZQBxZzfOqn1",
            "SXCi9B1KSHOo5A9209U6x9nXmHm2",
            "WmUasHazyvYrXqyz9pYpmgeqOI72",
            "srZuPbXxGNQ4i0VxAHOudEx3jLv1"
            ]

    ID = ""

    res = defaultdict()
    for i in keys:
        res = json.loads(requests.get(f'http://cricapi.com/api/cricket?apikey={i}').text)
        if not 'error' in res.keys():
            ID = i
            break

    resC = defaultdict()
    for i in range(len(res['data'])):
        if int(res['data'][i]['unique_id']) == id :
            resC = res['data'][i]
            break
    resS = json.loads(requests.get(f'https://cricapi.com/api/fantasySummary?apikey={ID}&unique_id={id}').text)

    # Adding team names according to batting order
    l = len(resS['data']['batting'][0]['title'])
    title = resS['data']['batting'][0]['title']
    title = title[::-1]     #reversing title
    title = title[27:l]
    title = title[::-1]
    resC['batfirst'] = title

    if  len(resS['data']['batting']) > 1  :
        l = len(resS['data']['batting'][1]['title'])
        title = resS['data']['batting'][1]['title']
        title = title[::-1]
        title = title[41:l]
        title = title[::-1]
        resC['batsecond'] = title
    else :
        resC['batsecond'] = "null"
    l = len(resC['description'])
    over = overs(resS)
    for index in range(0, l):
        if (resC['description'][index] == '/'):
            sone = resC['description'][0:index + 3]
            resC['team1'] = sone
            stwo = '(' + str(over['Oone']) + ')'
            resC['score1'] = sone + stwo
            sthree = resC['description'][index + 7:]
            resC['team2'] = resC['description'][index + 6:-8]
            sfour = '(' + str(over['Otwo']) + ')'
            resC['score2'] = sthree + sfour
            break

    a = "dismissal-info"
    b = "dismissal_info"        #changing '-' to '_' as it is more convinent to parse '_' in DTL
    for i in range(len(resS['data']['batting'])) :
        for j in resS['data']['batting'][i]['scores'] :
            j[b] = j.pop(a)

    if resS['data']['man-of-the-match'] !="" :
        a = 'man-of-the-match'
        b = 'man_of_the_match'
        resS['data'][b] = resS['data'].pop(a)

    resC['summary'] = resS
    return render(request, "scoreboard.html", {'resC': resC})

















    '''
    resL = json.loads(requests.get(
       'https://cricket.sportmonks.com/api/v2.0/livescores/A?api_token=I8N5NWb02kZsetMfvuR1eFXaotoOojIcF2T0jCz5BzIaXN4NVkEYV3rf3jgp&include=runs,venue,batting,bowling,localteam,visitorteam').text)
    fixture_index = 0
    Batlineup = defaultdict(list)  # initializing a Dictionary Obj
    Bowlineup = defaultdict(list)
    local_team = defaultdict(list)
    visitor_team = defaultdict(list)
    for i in range(len(resL)):
        if resL['data'][i]['id'] == A:
            Batlineup = resL['data'][i]['batting']
            Bowlineup = resL['data'][i]['bowling']
            fixture_index = i
            break
    l_team_id = resL["data"][fixture_index]["localteam_id"]
    v_team_id = resL["data"][fixture_index]["visitorteam_id"]

    #Adding team names and toss winners
        # adding toss winner team name in resL
    if resL['data'][fixture_index]['toss_won_team_id'] == resL['data'][fixture_index]['localteam_id']:
         resL['data'][fixture_index]['t_team_name'] = resL['data'][fixture_index]['localteam']['name']
         if resL['data'][fixture_index]['elected'] == 'bat':
                resL['data'][fixture_index]['batfirst'] = resL['data'][fixture_index]['localteam']['name']
                resL['data'][fixture_index]['batsecond'] = resL['data'][fixture_index]['visitorteam']['name']  # don't access id and name by .(dot operator) in views but use . in template -->  wasted so much time in that
         else:
                resL['data'][fixture_index]['batfirst'] = resL['data'][fixture_index]['visitorteam']['name']
                resL['data'][fixture_index]['batsecond'] = resL['data'][fixture_index]['localteam']['name']
    else:
            resL['data'][fixture_index]['t_team_name'] = resL['data'][fixture_index]['visitorteam']['name']
            if resL['data'][fixture_index]['elected'] == 'bat':
                resL['data'][fixture_index]['batfirst'] = resL['data'][fixture_index]['visitorteam']['name']
                resL['data'][fixture_index]['batsecond'] = resL['data'][fixture_index]['localteam']['name']
            else:
                resL['data'][fixture_index]['batfirst'] = resL['data'][fixture_index]['localteam']['name']
                resL['data'][fixture_index]['batsecond'] = resL['data'][fixture_index]['visitorteam']['name']


    # getting team squads
    resLT = json.loads(requests.get(
     'https://cricket.sportmonks.com/api/v2.0/teams/?api_token=I8N5NWb02kZsetMfvuR1eFXaotoOojIcF2T0jCz5BzIaXN4NVkEYV3rf3jgp&include=squad').text)

    flag = 0
    local_team_index = 0
    visitor_team_index = 0
    j = resLT['data']
    for i in range(len(j)):
        if j[i]['id'] == l_team_id:
            local_team = j[i]['squad']
            local_team_index = i
            resL['data'][fixture_index]['localteam_name'] = j[i]['name']
            flag = flag + 1
        if j[i]['id'] == v_team_id:
            visitor_team = j[i]['squad']
            visitor_team_index = i
            resL['data'][fixture_index]['visitorteam_name'] = j[i]['name']
            flag = flag + 1
        if flag == 2:
            break

    # Adding player name

    # local team batsman

    for i in range(len(Batlineup)):
        for k in range(len(local_team)):
            if Batlineup[i]['player_id'] == local_team[k]['id']:
                resL['data'][fixture_index]['batting'][i]['player_name'] = local_team[k]['fullname']

    # local team bowlers
    for i in range(len(Bowlineup)):
        for k in range(len(local_team)):
            if Bowlineup[i]['player_id'] == local_team[k]['id']:
                resL['data'][fixture_index]['bowling'][i]['player_name'] = local_team[k]['fullname']

    # visitor team batsman
    for i in range(len(Batlineup)):
        for k in range(len(visitor_team)):
            if Batlineup[i]['player_id'] == visitor_team[k]['id']:
                resL['data'][fixture_index]['batting'][i]['player_name'] = visitor_team[k]['fullname']

    # visitor team bowlers
    for i in range(len(Bowlineup)):
        for k in range(len(visitor_team)):
            if Bowlineup[i]['player_id'] == visitor_team[k]['id']:
                resL['data'][fixture_index]['bowling'][i]['player_name'] = visitor_team[k]['fullname']
    '''


